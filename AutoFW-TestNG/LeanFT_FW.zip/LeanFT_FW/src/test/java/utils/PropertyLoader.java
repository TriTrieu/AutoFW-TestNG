package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


public class PropertyLoader {

	public static Properties configProp;

	public static void loadConfigurationProperties() throws IOException{
		configProp = new Properties();
		String filePath = System.getProperty("user.dir")+"\\resources\\config.properties";
		InputStream input = new FileInputStream(new File(filePath));
		configProp.load(input);
	}
	
	public static String getPropertyValue(String key){
		return configProp.getProperty(key);
	}
	
}

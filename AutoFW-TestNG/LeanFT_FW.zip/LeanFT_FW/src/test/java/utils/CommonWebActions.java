package utils;

import com.hp.lft.report.Status;
import com.hp.lft.sdk.web.EditFieldCommon;
import com.hp.lft.sdk.web.WebElement;

public class CommonWebActions extends UnitTestClassBase{	
	
	public CommonWebActions() {
		super();		
	}
	
	public <T extends WebElement> void click(T webElement, String webElementName) {
		try {
			webElement.highlight();
			webElement.click();			
			assertStep(String.format("Clicked on %s", webElementName), "", Status.Passed);				
		} catch (Exception ex) {
			assertStep(String.format("Clicked on %s", webElementName), String.format("ERROR: %s", ex.getMessage()), Status.Failed);	
		}
	}
	
	public <T extends EditFieldCommon> void setValue(T webElement, String value, String webElementName){
		try{
			webElement.setValue(value);
			assertStep(String.format("Input value [%s] into %s", value, webElementName), "", Status.Passed);
		}
		catch (Exception ex) {
			assertStep(String.format("Input value [%s] into %s", value, webElementName), String.format("ERROR: %s", ex.getMessage()), Status.Failed);
		}
	}
}

package utils;

import java.awt.image.RenderedImage;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.rules.TestWatcher;

import com.hp.lft.report.Reporter;
import com.hp.lft.report.Status;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.Browser;
import com.hp.lft.sdk.web.BrowserFactory;
import com.hp.lft.sdk.web.BrowserType;
import com.hp.lft.unittesting.UnitTestBase;
import com.hp.lft.verifications.Verify;

import utils.PropertyLoader;

public class UnitTestClassBase extends UnitTestBase {

	protected static UnitTestClassBase instance;
	protected static String className;
	protected String testName;
	protected static Browser browser;

	public static void globalSetup(Class<? extends UnitTestClassBase> testClass) throws Exception {
		if (instance == null)
			instance = testClass.newInstance();
		instance.classSetup();
	}

	@Before
	public void beforeTest() throws Exception {
		testSetup();
		PropertyLoader.loadConfigurationProperties();
		launchBrowser();
	}

	@After
	public void afterTest() throws Exception {
		// browser.close();
	}

	public static void globalTearDown() throws Exception {
		instance.classTearDown();
		getReporter().generateReport();
	}

	@ClassRule
	public static TestWatcher classWatcher = new TestWatcher() {
		@Override
		protected void starting(org.junit.runner.Description description) {
			className = description.getClassName();
		}
	};

	@Rule
	public TestWatcher watcher = new TestWatcher() {
		@Override
		protected void starting(org.junit.runner.Description description) {
			testName = description.getMethodName();
		}

		@Override
		protected void failed(Throwable e, org.junit.runner.Description description) {

	
//				screenshot = browser.getPage().getSnapshot();
//				Verify.isTrue(false, e.getMessage(), "", screenshot);
				setStatus(Status.Failed, e);
				testTearDownNoThrow();
	

		}

		@Override
		protected void succeeded(org.junit.runner.Description description) {
			setStatus(Status.Passed);
			testTearDownNoThrow();
		}
	};

	@Override
	protected String getTestName() {
		return testName;
	}

	@Override
	protected String getClassName() {
		return className;
	}

	private void launchBrowser() {

		String browserType = PropertyLoader.getPropertyValue("browser_type");
		String url = PropertyLoader.getPropertyValue("url");

		try {
			switch (browserType.toUpperCase()) {
			case "IE":
				browser = BrowserFactory.launch(BrowserType.INTERNET_EXPLORER);
				break;
			case "FIREFOX":
				browser = BrowserFactory.launch(BrowserType.FIREFOX);
				break;
			case "CHROME":
				browser = BrowserFactory.launch(BrowserType.CHROME);
				break;
			default:
				browser = BrowserFactory.launch(BrowserType.CHROME);
				break;
			}
			browser.navigate(url);
			browser.sync();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void assertStep(String stepName, String stepDescription, Status status) {
		try {
		

			if (status == Status.Passed) {
				Reporter.reportEvent(stepName, stepDescription, status);
				Assert.assertTrue(true);
			} else {
				RenderedImage screenshot = browser.getPage().getSnapshot();
				Reporter.reportEvent(stepName, stepDescription, status, screenshot);
				Assert.assertTrue(false);
			}

		} catch (Exception e) {
			System.out.println(String.format("ERROR occurred: %s", e.getMessage()));
		}
	}

}
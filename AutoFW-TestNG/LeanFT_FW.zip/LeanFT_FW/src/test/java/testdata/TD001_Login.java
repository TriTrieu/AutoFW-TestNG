package testdata;

public class TD001_Login {

	private String userName;
	private String password;

	public TD001_Login() {
		super();
		this.userName = "T_ECPRE5_XT0";
		this.password = "ECMFuture#02!";
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}

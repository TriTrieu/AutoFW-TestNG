package pages;

import com.hp.lft.sdk.GeneralLeanFtException;

import LeanFT_FW.ApplicationModel;
import utils.CommonWebActions;

public class LoginPage extends CommonWebActions{
	ApplicationModel appModel;
	
	public LoginPage() {
		super();
		try {
			appModel = new ApplicationModel(browser);
		} catch (GeneralLeanFtException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void login(String userName, String password){		
		setValue(appModel.LoginPageObjects().sapUserEditField(), userName, "[User] EditField");
		setValue(appModel.LoginPageObjects().sapPasswordEditField(), password, "[Password] EditField");
		click(appModel.LoginPageObjects().logOnLink(), "[Log On] link");
	}

}

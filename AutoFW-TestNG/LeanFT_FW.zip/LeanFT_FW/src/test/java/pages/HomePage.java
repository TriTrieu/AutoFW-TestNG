package pages;

import com.hp.lft.sdk.GeneralLeanFtException;

import LeanFT_FW.ApplicationModel;
import utils.CommonWebActions;

public class HomePage extends CommonWebActions {

	ApplicationModel appModel;

	public HomePage() {
		super();
		try {
			appModel = new ApplicationModel(browser);
		} catch (GeneralLeanFtException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

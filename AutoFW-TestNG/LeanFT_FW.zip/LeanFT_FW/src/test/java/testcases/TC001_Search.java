package testcases;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.hp.lft.report.ReportException;
import com.hp.lft.sdk.GeneralLeanFtException;
import pages.HomePage;
import utils.UnitTestClassBase;

public class TC001_Search extends UnitTestClassBase {

	HomePage homePage;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		instance = new TC001_Search();
		globalSetup(TC001_Search.class);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		globalTearDown();
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void search() throws GeneralLeanFtException, ReportException {
	}

}
